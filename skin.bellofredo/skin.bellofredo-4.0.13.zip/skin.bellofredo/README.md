# Bello-Kodi-15.x-Nightlies
Unofficial Port of the Bello Skin (by Nessus) for the Kodi 15.x Nightlies

Official Bello GitHub branch: https://github.com/Nessus85100/Bello
Skin Thread on Kodi.tv: http://forum.kodi.tv/forumdisplay.php?fid=198
